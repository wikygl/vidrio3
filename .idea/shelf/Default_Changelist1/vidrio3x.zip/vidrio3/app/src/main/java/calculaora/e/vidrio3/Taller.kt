package calculaora.e.vidrio3

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.btn_calculadora_main
import kotlinx.android.synthetic.main.activity_taller.*

class Taller : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_taller)

        puerta.setOnClickListener {
            startActivity(Intent(this, PuertaPano::class.java))}

        btn_calculadora_main.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))}

        btn_novaina.setOnClickListener {
            startActivity(Intent(this, NovaIna::class.java))}

        btn_novaapa.setOnClickListener {
            startActivity(Intent(this, NovaApa::class.java))}

        btn_mpaflon.setOnClickListener {
            startActivity(Intent(this, MamparaPaflon::class.java))}

    }

}