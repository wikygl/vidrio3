package calculaora.e.vidrio3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


@Suppress("NAME_SHADOWING", "UNUSED_ANONYMOUS_PARAMETER")
class MainActivity : AppCompatActivity() {

    private var lista: MutableList<Listado> = mutableListOf()

    @RequiresApi(Build.VERSION_CODES.N)
    val decimalFormat = android.icu.text.DecimalFormat(0.00.toString().replace(",","."))

    /*resultadoText.text = if("$result".endsWith(".0")) { "$result".replace(".0","") } else { "%.2f".format(result) }*/
    @SuppressLint("NewApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnLimpiar.setOnClickListener {
            try {
                precio_unitario.text = "0.0"
                precio_cantidad.text = "0.0"
                pc_txt.text = "0.0"
                mc_txt.text = "0.0"
                med1_editxt.setText("")
                med2_editxt.setText("")
                cant_editxt.setText("")
                precio_editxt.setText("")
                pro_editxt.setText("")
                cliente_editxt.setText("")
                med1_editxt.hint = ""
                med2_editxt.hint = ""
                cant_editxt.hint = ""
                precio_total.text = "0.0"
                pies_total.text = "0.0"
                per.text = "0.0"
                lista.clear()
                list.onRemoteAdapterConnected()
                actualizar()
            } catch (e: Exception) {
            }
        }

        btnCalcular.setOnClickListener {
            try {

                val medida1 = med1_editxt.text.toString().toFloat()
                val medida2 = med2_editxt.text.toString().toFloat()
                val cantidad = cant_editxt.text.toString().toInt()
                val precio = precio_editxt.text.toString().toFloat()
                val producto = pro_editxt.text.toString()
                //val retaso=1.8F
                val piescua = (medida1) * (medida2) / 900
                val piescant = piescua * cantidad.toFloat()
                val metroscua = medida1 * medida2 / 10000 * cantidad.toFloat()
                val peri =(((medida1+0.4f)*2+(medida2+0.4f)*2)*cantidad)/100

                val costounitario = piescant * precio / cantidad
                val costocantidad = piescant * precio

                pc_txt.text = decimalFormat.format(piescant)
                mc_txt.text = decimalFormat.format(metroscua)
                precio_unitario.text = decimalFormat.format(costounitario)
                precio_cantidad.text = decimalFormat.format(costocantidad)

                med1_editxt.setText("")
                med1_editxt.hint = "$medida1"
                med2_editxt.setText("")
                med2_editxt.hint = "$medida2"
                cant_editxt.setText("")
                cant_editxt.hint = "$cantidad"

                val medidas =
                    Listado(medida1, medida2, cantidad, piescant, precio, costocantidad, producto,peri,metroscua)

                lista.add(medidas)
                actualizar()
               // listado()

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "ingrese un número válido", Toast.LENGTH_LONG).show()
            }
        }

        precio_total.setOnClickListener {
            startActivity(Intent(this, VendePapa::class.java).putExtra(
                    "monto",precio_total.text.toString()))
        }
        listado_txt.setOnClickListener {
            startActivity(Intent(this, Lista::class.java).putExtra("monto",per.text.toString()))
        }
        taller_cal.setOnClickListener {
            startActivity(Intent(this, Taller::class.java))
        }

        /* list.setOnItemClickListener { parent, view, position, id ->
            try {
                var indice = lista[position]
                var dialogo = AlertDialog.Builder(this)
                var modelo= layoutInflater.inflate(R.layout.dialogo,null)
                val eliminar = modelo.findViewById<Button>(R.id.btn_dialogo_eliminar)
                val editar = modelo.findViewById<Button>(R.id.btn_dialogo_editar)
                dialogo.setView(modelo)
                var dialogoper=dialogo.create()
                dialogoper.show()
                eliminar.setOnClickListener(){
                    fileList()[position]
                }
                editar.setOnClickListener(){}

                actualizar()


            } catch (e: Exception){}
        }*/

    }

    private fun actualizar() = try {
        val listaString = mutableListOf<String>()
        for (medidas in lista) {
            listaString.add(
                "${medidas.medi1} x ${medidas.medi2} x ${medidas.canti} = ${
                    decimalFormat.format(medidas.piescua)
                } x S/.${medidas.precio}" +
                        " == S/.${decimalFormat.format(medidas.costo)} -> ${medidas.producto}"
            )

            for (@Suppress("NAME_SHADOWING") listaString in lista) {
                var costo = 0F
                var metroscua = 0F
                var piescua = 0F
                var peri = 0F
                for (listaString in lista) {
                    costo += listaString.costo.toString().toFloat()
                    metroscua += listaString.metcua.toString().toFloat()
                    piescua += listaString.piescua.toString().toFloat()
                    peri += listaString.peri.toString().toFloat()
                }
                precio_total.text = decimalFormat.format(costo)
                metros_total.text = decimalFormat.format(metroscua)
                pies_total.text = decimalFormat.format(piescua)
                per.text = decimalFormat.format(peri)
            }

            /*
            list.setOnItemClickListener { parent, view, position, id
            ->
            try {
            var indice = listaString
            val dialogo = AlertDialog.Builder(this)
            val modelo= layoutInflater.inflate(R.layout.dialogo,null)
            val eliminar = modelo.findViewById<Button>(R.id.btn_dialogo_eliminar)
            val editar = modelo.findViewById<Button>(R.id.btn_dialogo_editar)
            val irlista = modelo.findViewById<Button>(R.id.btn_dialogo_lista)
            dialogo.setView(modelo)
            var dialogoper=dialogo.create()
            dialogoper.show()
            eliminar.setOnClickListener{
            for (medidas in lista){
            list.onRemoteAdapterConnected()
            }
            }
            editar.setOnClickListener{

            }
            irlista.setOnClickListener{
            //ojo cambiar para generar un activity con la lista.
            startActivity(Intent(this,Lista::class.java).putExtra("indice",btn_dialogo_lista.text.toString()))
            }

            } catch (e: Exception){}

            / * list.setOnItemClickListener { parent, view, position, id ->
            try {
            val indice = lista[position]
            AlertDialog.Builder(this).apply {
            setTitle("Ojito,ojito!")
            setMessage("¿Qué desea hacer?")
            setPositiveButton("Eliminar") { dialogInterface: DialogInterface, i: Int ->
            list.onRemoteAdapterConnected()
            actualizar()
            }

            }.show()
            } catch (e: Exception){}
            }* /
            }
            */
            val adaptador = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaString)
            list.adapter = adaptador
        }
    } catch (e: Exception) {
    }

    /*private fun listado() {

        try {
            actualizar()
            val position = null
            val listaAString: String = lista.joinToString(position.toString())
            //val textItemList: String = listView.getItemAtPosition(position)
            metros_total.text = listaAString

        } catch (e: Exception) {
        }
    }*/
}




// resultadoText.text = if("$result".endsWith(".0")) { "$result".replace(".0","") } else { "%.2f".format(result) }