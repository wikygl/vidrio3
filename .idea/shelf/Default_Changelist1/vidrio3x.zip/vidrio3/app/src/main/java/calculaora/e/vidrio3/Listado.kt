package calculaora.e.vidrio3

import java.io.Serializable

class Listado(
    val medi1: Float,
    val medi2: Float,
    val canti: Int,
    val piescua: Float,
    val precio:Float,
    val costo: Float,
    val producto:String,
    val peri : Float,
    val metcua : Float

):Serializable