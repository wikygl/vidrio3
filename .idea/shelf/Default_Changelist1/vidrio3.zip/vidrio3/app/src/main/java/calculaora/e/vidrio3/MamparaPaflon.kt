package calculaora.e.vidrio3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_mampara_paflon.*

@Suppress("IMPLICIT_CAST_TO_ANY")
class MamparaPaflon : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    val decimalFormat = android.icu.text.DecimalFormat(0.00.toString())

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mampara_paflon)

        btn_calcular_fccfss.setOnClickListener {
            try {
                val ancho = med1_mfccfss.text.toString().toFloat()
                val alto = med2_mfccfss.text.toString().toFloat()
                val marco = marco_mfccfss.text.toString().toFloat()
                val altoHoja = altohoja_mfccfss.text.toString().toFloat()
                val bast = bast_mfccfss.text.toString().toFloat()
                val jun = junk_mfccfss.text.toString().toFloat()
                val anchoUtil = ancho - (2 * marco)


                marcotxt_mfccfss.text = "$alto = 2\n${decimalFormat.format(anchoUtil)} = 1"

                rieltxt_mfccfss.text = "${decimalFormat.format(anchoUtil)} = 1"

                angtxt_mfccfss.text = "${decimalFormat.format(anchoUtil)} = 2\n${altoHoja - 3.3} = 1"

                porttxt_mfccfss.text = "${altoHoja - 1.5} = 2"

                bastitxt_mfccfss.text = "${decimalFormat.format(zocaloTechoFijo())} = 2\n" +
                        "${decimalFormat.format(zocaloTechoCorrediza())} = 4\n" +
                        "${decimalFormat.format(paranteCorredizo())} = 4\n" +
                        "${decimalFormat.format(paranteFijo())} = 2\n" +
                        "${decimalFormat.format(paranteMocheta())} = 1\n" +
                        "${decimalFormat.format(anchoUtil)} = 1"

                if (jun == 0f) {
                    junkitxt_mfccfss.text = "${decimalFormat.format(zocaloTechoFijo())} = 4" +
                            "\n${decimalFormat.format(zocaloTechoCorrediza())} = 4" +
                            "\n${decimalFormat.format(paranteCorredizo() - (2 * bast))} = 4" +
                            "\n${decimalFormat.format(paranteFijo() - bast)} = 4" +
                            "\n${decimalFormat.format(paranteMocheta())} = 4" +
                            "\n${decimalFormat.format(anchoMocheta())}= 4"
                } else {
                    junkitxt_mfccfss.text = "${decimalFormat.format(zocaloTechoFijo())} = 4" +
                            "\n${decimalFormat.format(zocaloTechoCorrediza())} = 4" +
                            "\n${decimalFormat.format((paranteCorredizo() - (2 * bast)) - (2 * jun))} = 4" +
                            "\n${decimalFormat.format((paranteFijo() - bast) - (2 * jun))} = 4" +
                            "\n${decimalFormat.format(paranteMocheta() - (2 * jun))} = 4" +
                            "\n${decimalFormat.format(anchoMocheta())}= 4"
                }

                vidriostxt_mfccfss.text =
                    "${decimalFormat.format(zocaloTechoFijo() - 0.4f)} x ${altoVidrioFijo()} = 2\n" +
                            "${decimalFormat.format(zocaloTechoCorrediza() - 0.4f)} x" +
                            " ${decimalFormat.format(altoVidrioCorredizo())} = 2\n" +
                            "${decimalFormat.format(paranteMocheta() - 0.4f)} x " +
                            "${decimalFormat.format(anchoMocheta()- 0.4f) } = 2"
            }catch (e: Exception) {
                Toast.makeText(this, "Ingrese dato válido", Toast.LENGTH_SHORT).show()}
        }

        btn_archivar_fccfss.setOnClickListener{
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",marcotxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",bastitxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",rieltxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",junkitxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",angtxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",porttxt_mfccfss.text.toString()))
            startActivity(Intent(this,Lista::class.java).putExtra(
                "monto",vidriostxt_mfccfss.text.toString()))
        }
    }
    private fun zocaloTechoFijo(): Float {
        val ancho = med1_mfccfss.text.toString().toFloat()
        val marco = marco_mfccfss.text.toString().toFloat()
        val bast = bast_mfccfss.text.toString().toFloat()
        val anchoUtil=  ancho - (2*marco)
        return (anchoUtil - (2 * bast)) / 4
    }
    private fun zocaloTechoCorrediza(): Float {
        val ancho = med1_mfccfss.text.toString().toFloat()
        val marco = marco_mfccfss.text.toString().toFloat()
        val bast = bast_mfccfss.text.toString().toFloat()
        val anchoUtil=  ancho - (2*marco)
        return ((anchoUtil - (2 * bast)) / 4)-bast
    }
    private fun paranteCorredizo():Float{
        val altoHoja=altohoja_mfccfss.text.toString().toFloat()
        return altoHoja-2.2f
    }
    private fun paranteFijo(): Float {
        return altohoja_mfccfss.text.toString().toFloat()
    }
    private fun paranteMocheta():Float {
        val marco = marco_mfccfss.text.toString().toFloat()
        val bastidor= bast_mfccfss.text.toString().toFloat()
        val altoHoja=altohoja_mfccfss.text.toString().toFloat()
        val alto = med2_mfccfss.text.toString().toFloat()
        return ((alto-altoHoja)- (marco+bastidor))
    }
    private fun anchoMocheta():Float{
        val ancho = med1_mfccfss.text.toString().toFloat()
        val marco = marco_mfccfss.text.toString().toFloat()
        val bastidor= bast_mfccfss.text.toString().toFloat()
        val anchoUtil=  ancho - (2*marco)
        return (anchoUtil-bastidor)/2
    }
    private fun altoVidrioFijo(): Float {
        val bastidor= bast_mfccfss.text.toString().toFloat()
        val altoHoja=altohoja_mfccfss.text.toString().toFloat()
        val holgura = 0.4f
        return altoHoja-(bastidor+holgura)
    }
    private fun altoVidrioCorredizo(): Float {
        val bastidor= bast_mfccfss.text.toString().toFloat()
        val holgura = 0.4f
        return paranteCorredizo()-((2*bastidor)+holgura)
    }
}