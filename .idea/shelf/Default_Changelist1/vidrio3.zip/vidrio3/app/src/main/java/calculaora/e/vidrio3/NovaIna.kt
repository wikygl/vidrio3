package calculaora.e.vidrio3

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_nova_ina.*

@Suppress("IMPLICIT_CAST_TO_ANY")
class NovaIna : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.N)
    val df = android.icu.text.DecimalFormat(0.0.toString())

    @SuppressLint("SetTextI18n", "ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nova_ina)

        u13layout.visibility = View.GONE
        u38layout.visibility = View.GONE
        ulayout.visibility = View.VISIBLE


        btn_calcular_nfcfs.setOnClickListener {
            try {
                val ancho = med1_nfcfi.text.toString().toFloat()
                val alto=med2_nfcfi.text.toString().toFloat()
                val hoja= hojatxt_nfcfsi.text.toString().toFloat()
                val us = ueditxt_nfcfi.text.toString().toFloat()

                //OPCIONES DE VISIBILIDAD
                when (ueditxt_nfcfi.text.toString().toFloat()) {
                    1f -> {
                        u13layout.visibility = View.GONE
                        u38layout.visibility = View.VISIBLE
                        ulayout.visibility = View.GONE
                    }
                    1.5f -> {
                        u13layout.visibility = View.VISIBLE
                        u38layout.visibility = View.GONE
                        ulayout.visibility = View.GONE
                    }
                    else -> {
                        u13layout.visibility = View.GONE
                        u38layout.visibility = View.GONE
                        ulayout.visibility = View.VISIBLE
                    }
                }

                if (divisiones()==1){h_layout.visibility= View.GONE}
                else{h_layout.visibility = View.VISIBLE}

                if (divisiones()!=2){ang_layout.visibility= View.GONE}
                else{ang_layout.visibility = View.VISIBLE}

                if (divisiones()==1){porta_layout.visibility= View.GONE}
                else{porta_layout.visibility = View.VISIBLE}

                if (divisiones()==1 || alto<=hoja){ufel_layout.visibility= View.GONE}
                else{ufel_layout.visibility = View.VISIBLE}

                if (alto<=hoja && divisiones()>1){fc_layout.visibility= View.VISIBLE}
                else{fc_layout.visibility=View.GONE}

                if(alto<=hoja){tubo_layout.visibility= View.GONE}
                else{tubo_layout.visibility=View.VISIBLE}

                //VISIBILIDAD MODELOS
                if (divisiones()==1){f1.visibility= View.VISIBLE}else{f1.visibility= View.GONE}
                if (divisiones()==2&&alto<=hoja){f2c.visibility= View.VISIBLE}else{f2c.visibility= View.GONE}
                if (divisiones()==2&&alto>hoja){f2.visibility= View.VISIBLE}else{f2.visibility= View.GONE}
                if (divisiones()==3&&alto<=hoja){f3c.visibility= View.VISIBLE}else{f3c.visibility= View.GONE}
                if (divisiones()==3&&alto>hoja){f3.visibility= View.VISIBLE}else{f3.visibility= View.GONE}
                if (divisiones()==4&&alto<=hoja){f4c.visibility= View.VISIBLE}else{f4c.visibility= View.GONE}
                if (divisiones()==4&&alto>hoja){f4.visibility= View.VISIBLE}else{f4.visibility= View.GONE}
                if (divisiones()==5&&alto<=hoja){f5c.visibility= View.VISIBLE}else{f5c.visibility= View.GONE}
                if (divisiones()==5&&alto>hoja){f5.visibility= View.VISIBLE}else{f5.visibility= View.GONE}
                if (divisiones()==6&&alto<=hoja){f6c.visibility= View.VISIBLE}else{f6c.visibility= View.GONE}
                if (divisiones()==6&&alto>hoja){f6.visibility= View.VISIBLE}else{f6.visibility= View.GONE}
                if (divisiones()==7&&alto<=hoja){f7c.visibility= View.VISIBLE}else{f7c.visibility= View.GONE}
                if (divisiones()==7&&alto>hoja){f7.visibility= View.VISIBLE}else{f7.visibility= View.GONE}
                if (divisiones()==8&&alto<=hoja){f8c.visibility= View.VISIBLE}else{f8c.visibility= View.GONE}
                if (divisiones()==8&&alto>hoja){f8.visibility= View.VISIBLE}else{f8.visibility= View.GONE}
                if (divisiones()==9&&alto<=hoja){f9c.visibility= View.VISIBLE}else{f9c.visibility= View.GONE}
                if (divisiones()==9&&alto>hoja){f9.visibility= View.VISIBLE}else{f9.visibility= View.GONE}
                if (divisiones()==10&&alto<=hoja){f10c.visibility= View.VISIBLE}else{f10c.visibility= View.GONE}
                if (divisiones()==10&&alto>hoja){f10.visibility= View.VISIBLE}else{f10.visibility= View.GONE}
                if (divisiones()==11&&alto<=hoja){f11c.visibility= View.VISIBLE}else{f11c.visibility= View.GONE}
                if (divisiones()==11&&alto>hoja){f11.visibility= View.VISIBLE}else{f11.visibility= View.GONE}
                if (divisiones()==12&&alto<=hoja){f12c.visibility= View.VISIBLE}else{f12c.visibility= View.GONE}
                if (divisiones()==12&&alto>hoja){f12.visibility= View.VISIBLE}else{f12.visibility= View.GONE}
                if (divisiones()==13&&alto<=hoja){f11c.visibility= View.VISIBLE}else{f11c.visibility= View.GONE}
                if (divisiones()==13&&alto>hoja){f13.visibility= View.VISIBLE}else{f13.visibility= View.GONE}
                if (divisiones()==14&&alto<=hoja){f12c.visibility= View.VISIBLE}else{f12c.visibility= View.GONE}
                if (divisiones()==14&&alto>hoja){f14.visibility= View.VISIBLE}else{f14.visibility= View.GONE}
                if (divisiones()==15&&alto<=hoja){f11c.visibility= View.VISIBLE}else{f11c.visibility= View.GONE}
                if (divisiones()==15&&alto>hoja){f15.visibility= View.VISIBLE}else{f15.visibility= View.GONE}

                //CALCULO DE MATERIALES

                //CANAL U

                //u 13

                if (alto>hoja){u13txt_nfcfi.text= when {
                    divisiones()==2 -> {"${df.format(uFijos())} =" +
                            " ${nFijos()}\n${df.format(uParante())} = " +
                            "${fijoUParante()}\n${df.format(uParante2())} = 1\n${uSuperior()} = 1"}
                    divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                    else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}\n" +
                            "${uSuperior()} = 1"}}}
                else{u13txt_nfcfi.text= when {
                    divisiones()==2 -> {"${df.format(uFijos())} =" +
                            " ${nFijos()}\n${df.format(uParante())} = " +
                            "${fijoUParante()}"}
                    divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                    else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}"}}}

                //u 3/8

                if (alto>hoja){u38txt_nfcfi.text= when {
                    divisiones()==2 -> {"${df.format(uFijos())} =" +
                            " ${nFijos()}\n${df.format(uParante())} = " +
                            "${fijoUParante()}\n${df.format(uParante2())} = 1\n${uSuperior()} = 1"}
                    divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                    else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}\n" +
                            "${uSuperior()} = 1"}}}
                else{u38txt_nfcfi.text= when {
                    divisiones()==2 -> {"${df.format(uFijos())} =" +
                            " ${nFijos()}\n${df.format(uParante())} = " +
                            "${fijoUParante()}"}
                    divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                    else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}"}}}

                //u otros

            if (alto>hoja && us != 0F){uxxtxt_nfcfi.text= when {
                divisiones()==2 -> {"${df.format(uFijos())} =" +
                        " ${nFijos()}\n${df.format(uParante())} = " +
                        "${fijoUParante()}\n${df.format(uParante2())} = 1\n${uSuperior()} = 1"}
                divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}\n" +
                        "${uSuperior()} = 1"}}}

            else if(alto>hoja && us == 0F){uxxtxt_nfcfi.text= when {
                divisiones()==2 -> {"${df.format(uFijos())} =" +
                        " ${nFijos()}\n${uSuperior()} = 1"}
                divisiones()==1 -> {"${df.format(uFijos())} = 2"}
                else -> {"${df.format(uFijos())} = ${nFijos()}\n" +
                        "${uSuperior()} = 1"}}}

            else if(alto<=hoja && us != 0F){uxxtxt_nfcfi.text= when {
                divisiones()==2 -> {"${df.format(uFijos())} = ${nFijos()}\n" +
                        "${df.format(uParante())} = ${fijoUParante()}\n${df.format(uParante2())} = 1"}
                divisiones()==1 -> {"${df.format(uFijos())} = 2\n${df.format(uParante())} =2"}
                else -> {"${df.format(uFijos())} = ${nFijos()}\n${df.format(uParante())} = ${fijoUParante()}"}}}

            else{uxxtxt_nfcfi.text= when {
                divisiones()==2 -> {"${df.format(uFijos())} = ${nFijos()}"}
                divisiones()==1 -> {"${df.format(uFijos())} = 2"}
                else -> {"${df.format(uFijos())} = ${nFijos()}"}}}

                // PUENTE
                multitxt_nfcfi.text = puentes()

                // RIEL
                rieltxt_nfcfi.text = if(divisiones()==1){""}else{rieles()}

                // U FELPERO, FIJO COREDIZO
                angcortotxt_nfcfi.text = if(divisiones()==1){""}else{rieles()}

                fctxt_nfcfs.text = if(divisiones()==1){""}else{rieles()}

                // HACHE
                hachetxt_nfcfi.text = "${df.format(hache())} = ${nCorredizas()}"

                //REFERENCIAS

                referencias_nfcfi.text= "An: $ancho  x  Al: $alto\nAltura de puente:${if (alto>hoja){
                    df.format(altoHoja())}else{"sin puente"}}\nDivisiones:" +
                        " ${divisiones()} -> fjs: ${nFijos()};czs: ${nCorredizas()}"

                //ÁNGULO TOPE
                if (divisiones() == 2) {angtxt_nfcfi.text="${df.format(altoHoja()-0.9f)} = 1"}
                else{ang_layout.visibility=View.GONE}

                // PORTAFELPA
                portxt_nfcfi.text = "${df.format(portafelpa())} = ${divDePortas()}"

                //VIDRIOS
                vidriotxt_nfcfi.text =if (divisiones()>1){"${vidrioFijo()}\n${vidrioCorre()}\n${vidrioMocheta()}"}
                else{vidrioFijo()}

            } catch (e: Exception) {
                Toast.makeText(this, "Ingrese dato válido", Toast.LENGTH_SHORT).show()}
        }
    }

    // FUNCIONES U
    private fun uFijos(): Float {
        val ancho = med1_nfcfi.text.toString().toFloat()
        val cruce = (divisiones()-1)*0.7
        val partes= (ancho+cruce)/divisiones()
        return if (divisiones()==1){ancho}else{partes.toFloat()}
    }
    private fun uParante():Float {
        val alto=med2_nfcfi.text.toString().toFloat()
        val us = ueditxt_nfcfi.text.toString().toFloat()
        return alto-(2*us)
    }
    private fun uParante2():Float {
        val alto=med2_nfcfi.text.toString().toFloat()
        val us = ueditxt_nfcfi.text.toString().toFloat()
        return ((alto-altoHoja())-us)+1.5f
    }

    private fun uSuperior(): Float {
        return med1_nfcfi.text.toString().toFloat()
    }

    // FUNCIONES otros perfiles

    private fun rieles(): String {
        val alto=med2_nfcfi.text.toString().toFloat()
        val hoja= hojatxt_nfcfsi.text.toString().toFloat()
        val ancho = med1_nfcfi.text.toString().toFloat()
        return if (alto!=hoja) if (divisiones()!=14) {"${df.format(mPuentes()-0.06f)} = ${nPuentes()}"}
        else{"${df.format(mPuentes())} = ${nPuentes()-1}\n${df.format(mPuentes2())} = ${nPuentes()-2}"}
        else{"${df.format(ancho-0.06f)} = 1"}
    }
    private fun puentes(): String {
        val alto=med2_nfcfi.text.toString().toFloat()
        return when {
            divisiones()in 6..12 && divisiones()%2==0 -> {"${df.format(mPuentes()-0.06f)} = ${nPuentes()}\n" +
                    "$alto = ${nPuentes()-1}"}
            divisiones()==14 ->{"${df.format(mPuentes()-0.06f)} = ${nPuentes()-1}\n${df.format(mPuentes2())} =" +
                    " ${nPuentes()-2}\n$alto = ${nPuentes()-1}"}
            else -> {"${df.format(mPuentes()-0.06f)} = ${nPuentes()}"}
        }
    }
    private fun portafelpa():Float {
        return altoHoja()-1.6f
    }

    private fun hache():Float {
        return uFijos()
    }

    //FUNCI0NES VIDRIOS
    private fun vidrioFijo(): String {
        val alto=med2_nfcfi.text.toString().toFloat()
        val us = ueditxt_nfcfi.text.toString().toFloat()
        val holgura = if (us==0f){1f}else{0.2f}
        return when {
            divisiones()<5 -> {"${df.format(uFijos()-0.4f)} x ${df.format(alto-(us+holgura))} = " +
                    "${nFijos()}"}
            divisiones()==6||divisiones()==8-> {"${df.format(uFijos()-0.4f)} x " +
                    "${df.format(alto-(us+holgura))} = 2\n" +
                    "${df.format(uFijos()-0.2f)} x ${df.format(alto-(us+holgura))} = 2"}
            divisiones()==10 -> {"${df.format(uFijos()-0.4f)} x ${df.format(alto-(us+holgura))} = 2\n" +
                    "${df.format(uFijos()-0.2f)} x ${df.format(alto-(us+holgura))} = 2\n" +
                    "${df.format(uFijos())} x ${df.format(alto-(us+holgura))} = 2"}
            divisiones()==12 -> {"${df.format(uFijos()-0.4f)} x ${df.format(alto-(us+holgura))} = 2\n" +
                    "${df.format(uFijos() - 0.2f)} x ${df.format(alto - (us + holgura))} = 4"}
            divisiones()==14 -> {"${df.format(uFijos()-0.4f)} x ${df.format(alto-(us+holgura))} = 2\n" +
                    "${df.format(uFijos() - 0.2f)} x ${df.format(alto - (us + holgura))} = 4\n" +
                    "${df.format(uFijos())} x ${df.format(alto-(us+holgura))} = 2"}
            else -> {"${df.format(uFijos()-0.4f)} x ${df.format(alto-(us+holgura))} = " +
                    "2\n${df.format(uFijos())} x ${df.format(alto-(us+holgura))}= ${nFijos()-2}"}
        }
    }

    private fun vidrioCorre():String {
        return "${df.format(hache()-1.4f)} x ${df.format(altoHoja()-3.5f)} = ${nCorredizas()}"
    }

    private fun vidrioMocheta():String {
        val alto=med2_nfcfi.text.toString().toFloat()
        val ancho = med1_nfcfi.text.toString().toFloat()
        val hoja= hojatxt_nfcfsi.text.toString().toFloat()

        return when{
            divisiones()<=1 || alto<=hoja ->{""}
            divisiones()==4 ->{"${df.format((alto-altoHoja())+1)} x " +
                    "${df.format(((ancho-(nFijos()*uFijos())))-0.6f)} = 1"}
            divisiones()==8 ->{"${df.format((alto-altoHoja())+1)} x " +
                    "${df.format(((ancho-(nFijos()*uFijos()))/2)-0.6f)} = 2"}
            divisiones()==12 -> {"${df.format((alto-altoHoja())+1)} x " +
                    "${df.format(((ancho-(nFijos()*uFijos()))/3)-0.6f)} = 3"}
            divisiones()==14 -> {"${df.format((alto-altoHoja())+1)} x " +
                    "${df.format(((ancho-(nFijos()*uFijos()))/2)-0.6f)} = 1\n" +
                    "${df.format((alto-altoHoja())+1)} x ${df.format((ancho-(nFijos()*uFijos()))-0.6f)} = 4"}
            else->{"${df.format((alto-altoHoja())+1)} x " +
                    "${df.format(((ancho-(nFijos()*uFijos()))/nCorredizas())-0.6f)} = ${(nCorredizas())}"}
        }
    }

    //FUNCIONES GENERALES
    private fun altoHoja():Float {
        val alto=med2_nfcfi.text.toString().toFloat()
        val hoja= hojatxt_nfcfsi.text.toString().toFloat()
        val corre = if (hoja>alto){alto}else{hoja}
        return if (hoja==0f){alto/7*5}else{corre}
    }
    private fun divisiones(): Int {
        val ancho = med1_nfcfi.text.toString().toFloat()
        val divis = partes_nfcfi.text.toString().toInt()
        return if (divis == 0) {
            when {
                ancho <= 60 -> 1
                ancho in 60.0..120.0 -> 2
                ancho in 120.0..180.0 -> 3
                ancho in 180.0..240.0 -> 4
                ancho in 240.0..300.0 -> 5
                ancho in 300.0..360.0 -> 6
                ancho in 360.0..420.0 -> 7
                ancho in 420.0..480.0 -> 8
                ancho in 480.0..540.0 -> 9
                ancho in 540.0..600.0 -> 10
                ancho in 600.0..660.0 -> 11
                ancho in 660.0..720.0 -> 12
                ancho in 720.0..780.0 -> 13
                ancho in 780.0..840.0 -> 14
                ancho in 840.0..900.0 -> 15
                else -> divis
            }} else {divis}
    }
    private fun nFijos():Int {
        return when (divisiones()){
            1 -> 1  2 -> 1
            3 -> 2  4 -> 2
            5 -> 3
            6 -> 4  7 -> 4
            8 -> 4
            9 -> 5
            10 ->6  11 -> 6  12 -> 6
            13 ->7  14 ->8   15 -> 8
            else -> 0
        }
    }
    private fun nCorredizas():Int {
        return when (divisiones()){
            1 -> 0
            2 -> 1   3 -> 1
            4 -> 2   5 -> 2   6 -> 2
            7 -> 3
            8 -> 4   9 -> 4   10 -> 4
            11-> 5
            12-> 6   13-> 6   14 -> 6
            15-> 7
            else -> 0
        }
    }
    private fun fijoUParante():Int{
        return when (divisiones()){
            1 -> 2   2 -> 1
            in 3..15 -> 2
            else -> 0
        }
    }
    private fun nPuentes():Int {
        return when (divisiones()){
            1 -> 1   2 -> 1   3 -> 1    4 -> 1    5 -> 1
            7 -> 1   9 -> 1   11 -> 1   13 -> 1   15 -> 1
            6 -> 2   8 -> 2  10 -> 2   12 -> 3   14 -> 3
            else -> 0
        }
    }
    private fun mPuentes():Float {
        val ancho = med1_nfcfi.text.toString().toFloat()
        val parantes=2.5f
        return when (divisiones()){
            1 -> ancho   2 -> ancho   3 -> ancho    4 -> ancho    5 -> ancho
            7 -> ancho  9 -> ancho   11 -> ancho   13 -> ancho   15 -> ancho
            6 -> (ancho-parantes)/2   8 -> (ancho-parantes)/2  10 -> (ancho-parantes)/2
            12 -> (ancho-(2*parantes))/3   14 -> (ancho-(2*parantes))/divisiones()*5
            else -> 0f
        }
    }
    private fun mPuentes2():Float {
        val ancho = med1_nfcfi.text.toString().toFloat()
        val parantes=2.5f
        return when (divisiones()){
            14 -> (ancho-(2*parantes))/divisiones()*4
            else -> 0f
        }
    }
    private fun divDePortas(): String {
        return when (divisiones()){
            1 ->""
            2,4,8,12 -> "${nCorredizas()*3}"
            14 -> "${(nCorredizas()*4)-2}"
            else->"${nCorredizas()*4}"
        }
    }
}