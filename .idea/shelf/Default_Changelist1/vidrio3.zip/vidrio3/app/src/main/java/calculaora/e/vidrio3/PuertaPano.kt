package calculaora.e.vidrio3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_puerta_pano.*

@Suppress("IMPLICIT_CAST_TO_ANY")
class PuertaPano : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.N)
    val decimalFormat = android.icu.text.DecimalFormat(0.00.toString())
    private val hoja = 199f
    private val marco = 2.2f
    private val bastidor = 8.25f

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puerta_pano)



        btn_calcularp.setOnClickListener {
            try {
                val marcop = med2_p.text.toString().toFloat()
                val jun=junk_p.text.toString().toFloat()

                //OPCIONES DE VISIBILIDAD

                if (mocheta()>0){f3.visibility=View.VISIBLE}else{f3.visibility=View.GONE}
                if (mocheta()>0){f4.visibility=View.GONE}else{f4.visibility=View.VISIBLE}
                // MATERIALES

                marcotxt_p.text = "$marcop = 2\n${decimalFormat.format(marcoSuperior())} = 1"

                bastitxt_p.text =
                    "${decimalFormat.format(zocaloTechoCorre())} = 2\n${decimalFormat.format(parante())} = 2"

                junkitxt_p.text = if (mocheta()< 0f){"${decimalFormat.format(parante() - junquilloAlto())} = 2\n${
                    decimalFormat.format(zocaloTechoCorre())} = 2"}else{"${decimalFormat.format(parante() - 
                        junquilloAlto())} = 2\n${decimalFormat.format(zocaloTechoCorre())} = 2\n" +
                        "${decimalFormat.format(marcoSuperior())} = 2\n" +
                        "${decimalFormat.format(mocheta()-(2*jun))} = 2"}

                angtxt_p.text =
                    "${decimalFormat.format(marcoSuperior())} = 1\n${decimalFormat.format(hPuente())} = 2"

                vidriostxt_p.text =if (mocheta()< 0f){ "${vidrioC()} = 1"}else{ "${vidrioC()} =1\n" +
                        "${vidrioM()} = 1"}

                referencias_p.text = referen()
                if(tubo()==""){tubolayout.visibility = View.GONE}else{tubolayout.visibility = View.VISIBLE}
                pruebas.text="${tubo()} = 1"

                p.text= hPuente().toString()

            } catch (e: Exception) {
                Toast.makeText(this, "Ingrese dato válido", Toast.LENGTH_SHORT).show()
            }
        }
        btn_archivarp.setOnClickListener {
            startActivity(Intent(this, Lista::class.java).putExtra("monto",
                marcotxt_p.text.toString()))

            startActivity(Intent(this, Lista::class.java).putExtra("monto",
                bastitxt_p.text.toString()))

            startActivity(Intent(this, Lista::class.java).putExtra("monto",
                junkitxt_p.text.toString()))

            startActivity(Intent(this, Lista::class.java).putExtra("monto",
                angtxt_p.text.toString()))

            startActivity(Intent(this, Lista::class.java).putExtra("monto",
                vidriostxt_p.text.toString()))
        }
    }
    private fun marcoSuperior():Float{
        val ancho = med1_p.text.toString().toFloat()
        return ancho-(2*marco)
    }
    private fun tubo(): String {
        val ancho = med1_p.text.toString().toFloat()
        return if (mocheta()> 0f){decimalFormat.format(ancho-(2*marco))
        }else{""}
    }
    private fun zocaloTechoCorre(): Float {
        val ancho = med1_p.text.toString().toFloat()
        val holgura = 1f
        return ((ancho - (2 * marco)) - holgura) - (2*bastidor)
    }
    private fun parante():Float{
        val holgura= 1f
        val piso=piso_editext.text.toString().toFloat()
        return if(piso==0f){hPuente()-holgura}else{(hPuente()-(holgura/2))-piso}
    }
    private fun junquilloAlto():Float{
        val jun=junk_p.text.toString().toFloat()
        return (2*bastidor)+(2*jun)
    }
    private fun vidrioC(): String {
        val jun=junk_p.text.toString().toFloat()
        val holgura = if(jun==0f){0.4f}else{0.6f}
        val anchv = decimalFormat.format((zocaloTechoCorre() - holgura))
        val altv = decimalFormat.format((parante() - 2*bastidor)-holgura)
        return "$anchv x $altv"
    }
    private fun vidrioM(): String {
        val jun=junk_p.text.toString().toFloat()
        val holgura = if(jun==0f){0.4f}else{0.6f}
        return decimalFormat.format(marcoSuperior()-holgura) +
                " x ${decimalFormat.format(mocheta()-holgura)}"
    }
    private fun referen():String{
        val ancho=med1_p.text.toString()
        val alto=med2_p.text.toString()
        return if(mocheta()> 0f)
        {"anch $ancho x alt $alto\nAlto hoja = ${hPuente()}"}else{"anch $ancho x alt $alto"}
    }
    private fun mocheta():Float{
        val alto=med2_p.text.toString().toFloat()
        val tubo =2.5f
        return alto - (hPuente()+marco+tubo)
    }
    private fun hPuente():Float{
        val alto=med2_p.text.toString().toFloat()
        val hHoja=hoja_editxt.text.toString().toFloat()
        val pisog=piso_editext.text.toString().toFloat()
        val piso = if (pisog==0f){pisog}else{pisog-0.5f}
        return when {
            hHoja==0f -> when{
                alto>210f && (hoja+piso)< alto-5.3-> {hoja+piso}
                alto<=210f&&alto>hoja->{190f+piso}
                alto<=hoja -> {(alto-marco)}
                (hoja+piso)> alto-5.3-> {(alto-marco)}
                else -> {(alto-marco)+piso}}

            alto<=hHoja || (hHoja+piso)> alto-5.3-> {(alto-marco)}
            else -> {hHoja+piso}
        }
    }
}
