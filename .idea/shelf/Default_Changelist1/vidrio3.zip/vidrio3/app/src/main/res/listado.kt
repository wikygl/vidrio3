
class listado (val largo1:Double, val ancho:Double, val volumen:Double) { }